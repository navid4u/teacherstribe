<!DOCTYPE html>
<html lang="en">
<head>
          <meta charset="UTF-8">
          <meta http-equiv="X-UA-Compatible" content="IE=edge">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <link rel="stylesheet" href="./style/style.css">
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,300;1,100&display=swap" rel="stylesheet">
          <title>چت با هوش مصنوعی</title>
</head>
<body>
<form id="form" method="post" action="./engine/db.php">
          <center>
          <input id="input-get" type="text" name="str" required placeholder="سوال خود را وارد کنید"><br>
          <input id="btn-get" type="submit" value="کلیک کن!">
          </center>
</form>       
</body>
</html>

<!-----------------------------------
          scripted by sepehr.za !
------------------------------------->